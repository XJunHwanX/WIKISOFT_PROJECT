import { useState } from 'react';
import { StepIndicator } from './components/StepIndicator';
import { WelcomeScreen } from './components/WelcomeScreen';
import { InfoInputStep } from './components/InfoInputStep';
import { ExcelUploadStep } from './components/ExcelUploadStep';
import { AIVerificationStep } from './components/AIVerificationStep';
import { DownloadStep } from './components/DownloadStep';

export default function App() {
  const [currentStep, setCurrentStep] = useState(0);
  const [formData, setFormData] = useState({});
  const [uploadedFile, setUploadedFile] = useState<File | null>(null);

  const steps = [
    { number: 1, title: '정보 입력', description: '14개 질문에 답변' },
    { number: 2, title: '엑셀 첨부', description: 'Excel 명부 파일 업로드' },
    { number: 3, title: 'AI 검증', description: '자동 명부 검증 및 오류 검출' },
    { number: 4, title: '결과 다운로드', description: '검증된 Excel 파일 다운로드' },
  ];

  const handleNextStep = () => {
    if (currentStep < 4) {
      setCurrentStep(currentStep + 1);
    }
  };

  const handlePrevStep = () => {
    if (currentStep > 0) {
      setCurrentStep(currentStep - 1);
    }
  };

  const handleFormSubmit = (data: any) => {
    setFormData(data);
    handleNextStep();
  };

  const handleFileUpload = (file: File) => {
    setUploadedFile(file);
    handleNextStep();
  };

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Header */}
      <header className="bg-white border-b border-gray-200 px-8 py-4">
        <div className="max-w-7xl mx-auto">
          <h1 className="text-2xl font-semibold">WIKISOFT</h1>
          <p className="text-sm text-gray-500 mt-1">명부관리체계 AI 자동검증</p>
        </div>
      </header>

      <div className="max-w-7xl mx-auto px-8 py-12">
        {/* Step Indicator - only show when not on welcome screen */}
        {currentStep > 0 && (
          <StepIndicator steps={steps} currentStep={currentStep} />
        )}

        {/* Step Content */}
        <div className={currentStep > 0 ? "mt-12" : ""}>
          {currentStep === 0 && (
            <WelcomeScreen onStart={handleNextStep} />
          )}
          {currentStep === 1 && (
            <InfoInputStep onSubmit={handleFormSubmit} onBack={handlePrevStep} />
          )}
          {currentStep === 2 && (
            <ExcelUploadStep
              onFileUpload={handleFileUpload}
              onBack={handlePrevStep}
            />
          )}
          {currentStep === 3 && (
            <AIVerificationStep
              file={uploadedFile}
              onComplete={handleNextStep}
              onBack={handlePrevStep}
            />
          )}
          {currentStep === 4 && (
            <DownloadStep
              file={uploadedFile}
              formData={formData}
              onBack={handlePrevStep}
            />
          )}
        </div>
      </div>
    </div>
  );
}
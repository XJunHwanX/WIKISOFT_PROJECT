import { useState, useEffect } from 'react';
import { Button } from './ui/button';
import { Card } from './ui/card';
import { Progress } from './ui/progress';
import { Sparkles, CheckCircle, AlertCircle, FileSpreadsheet } from 'lucide-react';

interface AIVerificationStepProps {
  file: File | null;
  onComplete: () => void;
  onBack: () => void;
}

export function AIVerificationStep({ file, onComplete, onBack }: AIVerificationStepProps) {
  const [progress, setProgress] = useState(0);
  const [currentTask, setCurrentTask] = useState('');
  const [isComplete, setIsComplete] = useState(false);
  const [stats, setStats] = useState({
    totalRows: 0,
    validRows: 0,
    errorRows: 0,
    warningRows: 0,
  });

  const verificationTasks = [
    { progress: 20, task: '파일 구조 분석 중...', delay: 800 },
    { progress: 40, task: '데이터 형식 검증 중...', delay: 1200 },
    { progress: 60, task: '중복 데이터 확인 중...', delay: 1000 },
    { progress: 80, task: '필수 항목 검증 중...', delay: 1000 },
    { progress: 95, task: '오류 보고서 생성 중...', delay: 800 },
    { progress: 100, task: '검증 완료!', delay: 500 },
  ];

  useEffect(() => {
    let currentIndex = 0;
    let timeoutId: NodeJS.Timeout;

    const runVerification = () => {
      if (currentIndex < verificationTasks.length) {
        const task = verificationTasks[currentIndex];
        setProgress(task.progress);
        setCurrentTask(task.task);

        if (task.progress === 100) {
          setIsComplete(true);
          // Mock stats
          setStats({
            totalRows: 1247,
            validRows: 1198,
            errorRows: 32,
            warningRows: 17,
          });
        }

        timeoutId = setTimeout(() => {
          currentIndex++;
          runVerification();
        }, task.delay);
      }
    };

    runVerification();

    return () => {
      if (timeoutId) clearTimeout(timeoutId);
    };
  }, []);

  return (
    <Card className="p-8 bg-white">
      <div className="flex items-center gap-3 mb-6">
        <div className="w-12 h-12 bg-purple-100 rounded-full flex items-center justify-center">
          <Sparkles className="w-6 h-6 text-purple-600" />
        </div>
        <div>
          <h2 className="text-xl font-semibold">AI 명부 검증</h2>
          <p className="text-sm text-gray-500">AI가 자동으로 명부를 검증하고 오류를 검출합니다</p>
        </div>
      </div>

      <div className="space-y-6">
        {/* File Info */}
        {file && (
          <Card className="p-4 bg-gray-50 border-gray-200">
            <div className="flex items-center gap-3">
              <FileSpreadsheet className="w-5 h-5 text-gray-600" />
              <div>
                <p className="font-medium text-gray-900">{file.name}</p>
                <p className="text-sm text-gray-500">검증 진행 중</p>
              </div>
            </div>
          </Card>
        )}

        {/* Progress */}
        <div className="space-y-3">
          <div className="flex items-center justify-between">
            <p className="text-sm font-medium text-gray-700">{currentTask}</p>
            <p className="text-sm font-semibold text-purple-600">{progress}%</p>
          </div>
          <Progress value={progress} className="h-3" />
        </div>

        {/* Verification Steps */}
        <div className="space-y-2">
          {verificationTasks.slice(0, -1).map((task, index) => {
            const isCompleted = progress > task.progress;
            const isCurrent = !isCompleted && progress >= (index > 0 ? verificationTasks[index - 1].progress : 0);

            return (
              <div
                key={index}
                className={`flex items-center gap-3 p-3 rounded-lg transition-colors ${
                  isCompleted
                    ? 'bg-green-50'
                    : isCurrent
                    ? 'bg-purple-50'
                    : 'bg-gray-50'
                }`}
              >
                {isCompleted ? (
                  <CheckCircle className="w-5 h-5 text-green-600 flex-shrink-0" />
                ) : (
                  <div
                    className={`w-5 h-5 rounded-full border-2 flex-shrink-0 ${
                      isCurrent ? 'border-purple-600' : 'border-gray-300'
                    }`}
                  />
                )}
                <p
                  className={`text-sm ${
                    isCompleted
                      ? 'text-green-700 font-medium'
                      : isCurrent
                      ? 'text-purple-700 font-medium'
                      : 'text-gray-500'
                  }`}
                >
                  {task.task}
                </p>
              </div>
            );
          })}
        </div>

        {/* Results */}
        {isComplete && (
          <Card className="p-6 bg-gradient-to-br from-purple-50 to-blue-50 border-purple-200">
            <div className="flex items-start gap-4">
              <div className="w-12 h-12 bg-green-600 rounded-full flex items-center justify-center flex-shrink-0">
                <CheckCircle className="w-6 h-6 text-white" />
              </div>
              <div className="flex-1">
                <h3 className="font-semibold text-lg text-gray-900 mb-4">검증 완료</h3>
                <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
                  <div className="bg-white rounded-lg p-3 text-center">
                    <p className="text-2xl font-bold text-gray-900">{stats.totalRows.toLocaleString()}</p>
                    <p className="text-sm text-gray-600 mt-1">전체 행</p>
                  </div>
                  <div className="bg-white rounded-lg p-3 text-center">
                    <p className="text-2xl font-bold text-green-600">{stats.validRows.toLocaleString()}</p>
                    <p className="text-sm text-gray-600 mt-1">정상</p>
                  </div>
                  <div className="bg-white rounded-lg p-3 text-center">
                    <p className="text-2xl font-bold text-red-600">{stats.errorRows}</p>
                    <p className="text-sm text-gray-600 mt-1">오류</p>
                  </div>
                  <div className="bg-white rounded-lg p-3 text-center">
                    <p className="text-2xl font-bold text-yellow-600">{stats.warningRows}</p>
                    <p className="text-sm text-gray-600 mt-1">경고</p>
                  </div>
                </div>
              </div>
            </div>
          </Card>
        )}

        {/* Detected Issues Preview */}
        {isComplete && stats.errorRows > 0 && (
          <Card className="p-4 border-orange-200 bg-orange-50">
            <div className="flex items-start gap-3">
              <AlertCircle className="w-5 h-5 text-orange-600 mt-0.5" />
              <div>
                <p className="font-medium text-orange-900">발견된 오류</p>
                <ul className="text-sm text-orange-700 mt-2 space-y-1">
                  <li>• 중복된 데이터: 15건</li>
                  <li>• 필수 항목 누락: 12건</li>
                  <li>• 형식 오류: 5건</li>
                </ul>
                <p className="text-sm text-orange-700 mt-2">
                  상세 내용은 다운로드할 엑셀 파일에서 확인하실 수 있습니다.
                </p>
              </div>
            </div>
          </Card>
        )}

        {/* Buttons */}
        <div className="flex justify-between pt-4">
          <Button
            type="button"
            variant="outline"
            onClick={onBack}
            disabled={!isComplete}
            size="lg"
          >
            이전
          </Button>
          <Button
            type="button"
            onClick={onComplete}
            disabled={!isComplete}
            size="lg"
            className="px-8"
          >
            결과 다운로드
          </Button>
        </div>
      </div>
    </Card>
  );
}

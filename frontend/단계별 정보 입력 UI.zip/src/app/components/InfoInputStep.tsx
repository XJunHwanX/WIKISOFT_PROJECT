import { useState } from 'react';
import { Button } from './ui/button';
import { Label } from './ui/label';
import { Card } from './ui/card';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from './ui/select';
import { FileText } from 'lucide-react';

interface InfoInputStepProps {
  onSubmit: (data: any) => void;
  onBack: () => void;
}

export function InfoInputStep({ onSubmit, onBack }: InfoInputStepProps) {
  const [formData, setFormData] = useState({
    question1: '',
    question2: '',
    question3: '',
    question4: '',
    question5: '',
    question6: '',
    question7: '',
    question8: '',
    question9: '',
    question10: '',
    question11: '',
    question12: '',
    question13: '',
    question14: '',
  });

  const questions = [
    { id: 'question1', label: '1. 사외직팀자산', question: '회계 장부 반영 금액과 일치합니까?', type: 'yesno' },
    { id: 'question2', label: '2. 정년', question: '정년은 만 몇 세 입니까?', type: 'age' },
    { id: 'question3', label: '3. 입금피크제', question: '입금피크제 미적용 기입임니까?', type: 'yesno' },
    { id: 'question4', label: '4. 기타장기충당금클리', question: '기타장기충당금클리 미적용 기입임니까?', type: 'yesno' },
    { id: 'question5', label: '5. 퇴직금제도', question: '퇴직금제도는 발령제를 적용합니까?', type: 'yesno' },
    { id: 'question6', label: '6. 운용폰/호봉제', question: '호봉기준에 따른 호봉 미적용 기입임니까?', type: 'yesno' },
    { id: 'question7', label: '7. 재직일자', question: '합의후 산출기준 관련 회사계산A 적용 기입임니까?', type: 'yesno' },
    { id: 'question8', label: '8. 1년 미만 재직자', question: '1년 미만 재직자도 기재 하셨습니까?', type: 'yesno' },
    { id: 'question9', label: '9. 퇴직금 추계액', question: '모든 재직자의 당년도, 차년도 퇴직금 추계액을 입력하셨습니까? (1년 미만 재직자의 경우 일할 계산)', type: 'yesno' },
    { id: 'question10', label: '10. 기준급여', question: '3개월 미만 재직자의 경우 합법 근무 시 지급받는 급여로 기재 하셨습니까?', type: 'yesno' },
    { id: 'question11', label: '11. 평가기준일 퇴사자', question: '평가기준일 발생 퇴직금을 비용(미지급 포함) 처리 하셨습니까?', type: 'yesno' },
    { id: 'question12', label: '12. 평가기준일 퇴사자', question: '재직자명부에서 평가기준일 퇴사자 제외 하셨습니까?', type: 'yesno' },
    { id: 'question13', label: '13. 중간정산 대상자', question: '근로법 시행령 제3조에(퇴직금 중간정산 사유)에 해당합니까?', type: 'yesno' },
    { id: 'question14', label: '14. 평가기준일 퇴사자', question: '퇴직자명부에 평가기준일 퇴사자를 포함하셨습니까?', type: 'yesno' },
  ];

  const handleChange = (id: string, value: string) => {
    setFormData(prev => ({ ...prev, [id]: value }));
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    onSubmit(formData);
  };

  return (
    <Card className="p-8 bg-white">
      <div className="flex items-center gap-3 mb-6">
        <div className="w-12 h-12 bg-blue-100 rounded-full flex items-center justify-center">
          <FileText className="w-6 h-6 text-blue-600" />
        </div>
        <div>
          <h2 className="text-xl font-semibold">정보 입력</h2>
          <p className="text-sm text-gray-500">명부 검증을 위한 14개 질문에 답변해주세요</p>
        </div>
      </div>

      <form onSubmit={handleSubmit}>
        <div className="grid grid-cols-1 gap-6">
          {questions.map((question) => (
            <div key={question.id} className="space-y-3 p-4 bg-gray-50 rounded-lg">
              <Label htmlFor={question.id} className="font-semibold">
                {question.label}
              </Label>
              <p className="text-sm text-gray-600">{question.question}</p>
              
              {question.type === 'yesno' ? (
                <div className="flex gap-3 mt-2">
                  <button
                    type="button"
                    onClick={() => handleChange(question.id, '예')}
                    className={`flex-1 py-3 px-4 rounded-lg border-2 transition-all ${
                      formData[question.id as keyof typeof formData] === '예'
                        ? 'bg-blue-600 border-blue-600 text-white font-semibold'
                        : 'bg-white border-gray-300 text-gray-700 hover:border-blue-400'
                    }`}
                  >
                    예
                  </button>
                  <button
                    type="button"
                    onClick={() => handleChange(question.id, '아니오')}
                    className={`flex-1 py-3 px-4 rounded-lg border-2 transition-all ${
                      formData[question.id as keyof typeof formData] === '아니오'
                        ? 'bg-blue-600 border-blue-600 text-white font-semibold'
                        : 'bg-white border-gray-300 text-gray-700 hover:border-blue-400'
                    }`}
                  >
                    아니오
                  </button>
                </div>
              ) : (
                <Select
                  value={formData[question.id as keyof typeof formData]}
                  onValueChange={(value) => handleChange(question.id, value)}
                  required
                >
                  <SelectTrigger id={question.id} className="bg-white">
                    <SelectValue placeholder="나이를 선택하세요" />
                  </SelectTrigger>
                  <SelectContent>
                    {Array.from({ length: 16 }, (_, i) => i + 55).map((age) => (
                      <SelectItem key={age} value={`만 ${age}세`}>
                        만 {age}세
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              )}
            </div>
          ))}
        </div>

        <div className="flex justify-end gap-3 mt-8">
          <Button type="submit" size="lg" className="px-8">
            다음 단계
          </Button>
        </div>
      </form>
    </Card>
  );
}
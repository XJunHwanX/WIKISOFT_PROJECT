import { Button } from './ui/button';
import { Card } from './ui/card';
import { Download, FileSpreadsheet, CheckCircle, Mail, RotateCcw } from 'lucide-react';

interface DownloadStepProps {
  file: File | null;
  formData: any;
  onBack: () => void;
}

export function DownloadStep({ file, formData, onBack }: DownloadStepProps) {
  const handleDownload = () => {
    // Mock download functionality
    // In a real application, this would download the verified Excel file
    alert('검증된 엑셀 파일 다운로드가 시작됩니다.');
  };

  const handleEmailSend = () => {
    alert('검증 결과가 이메일로 전송되었습니다.');
  };

  const handleStartOver = () => {
    if (window.confirm('처음부터 다시 시작하시겠습니까?')) {
      window.location.reload();
    }
  };

  return (
    <Card className="p-8 bg-white">
      <div className="flex items-center gap-3 mb-6">
        <div className="w-12 h-12 bg-blue-100 rounded-full flex items-center justify-center">
          <Download className="w-6 h-6 text-blue-600" />
        </div>
        <div>
          <h2 className="text-xl font-semibold">검증 완료</h2>
          <p className="text-sm text-gray-500">오류 검증이 완료된 엑셀 파일을 다운로드하세요</p>
        </div>
      </div>

      <div className="space-y-6">
        {/* Success Message */}
        <Card className="p-6 bg-gradient-to-br from-green-50 to-emerald-50 border-green-200">
          <div className="flex items-start gap-4">
            <div className="w-12 h-12 bg-green-600 rounded-full flex items-center justify-center flex-shrink-0">
              <CheckCircle className="w-6 h-6 text-white" />
            </div>
            <div className="flex-1">
              <h3 className="font-semibold text-lg text-gray-900 mb-2">검증이 완료되었습니다!</h3>
              <p className="text-sm text-gray-700">
                AI 검증을 통해 오류가 수정되고 표시된 엑셀 파일이 준비되었습니다.
                아래 버튼을 클릭하여 파일을 다운로드하세요.
              </p>
            </div>
          </div>
        </Card>

        {/* File Info */}
        {file && (
          <Card className="p-6 bg-gray-50 border-gray-200">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-4">
                <div className="w-14 h-14 bg-green-600 rounded-lg flex items-center justify-center">
                  <FileSpreadsheet className="w-7 h-7 text-white" />
                </div>
                <div>
                  <p className="font-semibold text-gray-900">
                    {file.name.replace('.xlsx', '_검증완료.xlsx').replace('.xls', '_검증완료.xls')}
                  </p>
                  <p className="text-sm text-gray-500 mt-1">검증 완료 • 다운로드 준비됨</p>
                </div>
              </div>
            </div>
          </Card>
        )}

        {/* Download Options */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          <Card className="p-6 border-blue-200 hover:border-blue-400 transition-colors cursor-pointer bg-gradient-to-br from-blue-50 to-blue-100">
            <div className="text-center space-y-3">
              <div className="w-12 h-12 bg-blue-600 rounded-full flex items-center justify-center mx-auto">
                <Download className="w-6 h-6 text-white" />
              </div>
              <div>
                <h3 className="font-semibold text-gray-900">파일 다운로드</h3>
                <p className="text-sm text-gray-600 mt-1">검증된 엑셀 파일 다운로드</p>
              </div>
              <Button onClick={handleDownload} className="w-full mt-4" size="lg">
                <Download className="w-4 h-4 mr-2" />
                다운로드
              </Button>
            </div>
          </Card>

          <Card className="p-6 border-purple-200 hover:border-purple-400 transition-colors cursor-pointer bg-gradient-to-br from-purple-50 to-purple-100">
            <div className="text-center space-y-3">
              <div className="w-12 h-12 bg-purple-600 rounded-full flex items-center justify-center mx-auto">
                <Mail className="w-6 h-6 text-white" />
              </div>
              <div>
                <h3 className="font-semibold text-gray-900">이메일 전송</h3>
                <p className="text-sm text-gray-600 mt-1">등록된 이메일로 결과 전송</p>
              </div>
              <Button
                onClick={handleEmailSend}
                variant="outline"
                className="w-full mt-4 border-purple-300 hover:bg-purple-100"
                size="lg"
              >
                <Mail className="w-4 h-4 mr-2" />
                이메일 전송
              </Button>
            </div>
          </Card>
        </div>

        {/* Verification Summary */}
        <Card className="p-6 bg-white border-gray-200">
          <h3 className="font-semibold text-gray-900 mb-4">검증 요약</h3>
          <div className="space-y-3">
            <div className="flex justify-between items-center py-2 border-b border-gray-100">
              <span className="text-sm text-gray-600">조직명</span>
              <span className="text-sm font-medium text-gray-900">{formData.question1 || '-'}</span>
            </div>
            <div className="flex justify-between items-center py-2 border-b border-gray-100">
              <span className="text-sm text-gray-600">담당자</span>
              <span className="text-sm font-medium text-gray-900">{formData.question2 || '-'}</span>
            </div>
            <div className="flex justify-between items-center py-2 border-b border-gray-100">
              <span className="text-sm text-gray-600">명부 유형</span>
              <span className="text-sm font-medium text-gray-900">{formData.question5 || '-'}</span>
            </div>
            <div className="flex justify-between items-center py-2">
              <span className="text-sm text-gray-600">검증 일시</span>
              <span className="text-sm font-medium text-gray-900">
                {new Date().toLocaleString('ko-KR')}
              </span>
            </div>
          </div>
        </Card>

        {/* Action Buttons */}
        <div className="flex justify-between pt-4">
          <Button
            type="button"
            variant="outline"
            onClick={handleStartOver}
            size="lg"
          >
            <RotateCcw className="w-4 h-4 mr-2" />
            처음부터 다시
          </Button>
          <Button
            type="button"
            onClick={handleDownload}
            size="lg"
            className="px-8"
          >
            <Download className="w-4 h-4 mr-2" />
            파일 다운로드
          </Button>
        </div>
      </div>
    </Card>
  );
}
